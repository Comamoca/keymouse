# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['keymouse']

package_data = \
{'': ['*']}

install_requires = \
['PyAutoGUI>=0.9.53,<0.10.0', 'keyboard>=0.13.5,<0.14.0']

setup_kwargs = {
    'name': 'keymouse',
    'version': '0.1.0',
    'description': 'キーボードでマウスを操作するコマンド',
    'long_description': None,
    'author': 'Comamoca',
    'author_email': 'comamoca.dev@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

import keyboard
import pyautogui

if __name__ == "__main__":
    HOTKEY = "ctrl" + "+"

    def move_cursor_right():
        pyautogui.move(0,10)

    def move_cursor_left():
        pyautogui(0, -10)

    def move_cursor_up():
        pyautogui(10,0)

    def move_cursor_down():
        pyautogui(-10, 0)

    keyboard.add_hotkey(HOTKEY + 'up', move_cursor_up)
    keyboard.add_hotkey(HOTKEY + 'down', move_cursor_down)
    keyboard.add_hotkey(HOTKEY + 'right', move_cursor_right)
    keyboard.add_hotkey(HOTKEY + 'left', move_cursor_left)

    keyboard.wait()
